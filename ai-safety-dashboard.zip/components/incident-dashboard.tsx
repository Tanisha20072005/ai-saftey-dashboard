"use client"

import { useState } from "react"
import { IncidentList } from "./incident-list"
import { NewIncidentForm } from "./new-incident-form"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import type { Incident } from "@/lib/types"

// Mock data as provided in the assignment
const initialIncidents: Incident[] = [
  {
    id: 1,
    title: "Biased Recommendation Algorithm",
    description:
      "Algorithm consistently favored certain demographics in job recommendations, leading to unequal opportunity distribution across different user groups. The bias was traced to imbalanced training data.",
    severity: "Medium",
    reported_at: "2025-03-15T10:00:00Z",
  },
  {
    id: 2,
    title: "LLM Hallucination in Critical Info",
    description:
      "LLM provided incorrect safety procedure information when queried about emergency protocols in a manufacturing setting. This could have led to dangerous situations if the information had been followed.",
    severity: "High",
    reported_at: "2025-04-01T14:30:00Z",
  },
  {
    id: 3,
    title: "Minor Data Leak via Chatbot",
    description:
      "Chatbot inadvertently exposed non-sensitive user metadata during conversation. The leak was contained to session information and did not include personally identifiable information.",
    severity: "Low",
    reported_at: "2025-03-20T09:15:00Z",
  },
  {
    id: 4,
    title: "Autonomous Vehicle Decision Error",
    description:
      "AI system in test vehicle made an unexpected lane change decision that contradicted traffic rules. No accident occurred, but the behavior was flagged for review.",
    severity: "Medium",
    reported_at: "2025-03-25T16:45:00Z",
  },
  {
    id: 5,
    title: "Content Moderation False Positive",
    description:
      "AI content filter incorrectly flagged educational medical content as inappropriate, blocking access to legitimate health information for users.",
    severity: "Low",
    reported_at: "2025-03-18T11:30:00Z",
  },
]

export function IncidentDashboard() {
  const [incidents, setIncidents] = useState<Incident[]>(initialIncidents)
  const [showForm, setShowForm] = useState(false)

  const addIncident = (incident: Omit<Incident, "id" | "reported_at">) => {
    const newIncident: Incident = {
      ...incident,
      id: Math.max(0, ...incidents.map((i) => i.id)) + 1,
      reported_at: new Date().toISOString(),
    }

    setIncidents([newIncident, ...incidents])
    setShowForm(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-xl font-semibold text-gray-800">Incident Reports</h2>
        <Button onClick={() => setShowForm(!showForm)} className="w-full sm:w-auto">
          <PlusCircle className="mr-2 h-4 w-4" />
          {showForm ? "Cancel" : "Report New Incident"}
        </Button>
      </div>

      {showForm && (
        <div className="rounded-lg border bg-white p-4 shadow-sm">
          <NewIncidentForm onSubmit={addIncident} />
        </div>
      )}

      <IncidentList incidents={incidents} />
    </div>
  )
}
