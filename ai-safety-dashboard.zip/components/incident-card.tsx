"use client"

import { formatDate } from "@/lib/utils"
import type { Incident } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface IncidentCardProps {
  incident: Incident
  isExpanded: boolean
  onToggleExpand: () => void
}

export function IncidentCard({ incident, isExpanded, onToggleExpand }: IncidentCardProps) {
  const { title, severity, reported_at, description } = incident

  return (
    <div className="overflow-hidden rounded-lg border bg-white shadow-sm transition-all hover:shadow">
      <div className="flex flex-col gap-2 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h3 className="font-medium text-gray-900">{title}</h3>
          <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500">
            <span>Reported: {formatDate(reported_at)}</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <SeverityBadge severity={severity} />
          <Button variant="ghost" size="sm" onClick={onToggleExpand} className="flex items-center gap-1">
            {isExpanded ? (
              <>
                <span>Hide Details</span>
                <ChevronUp className="h-4 w-4" />
              </>
            ) : (
              <>
                <span>View Details</span>
                <ChevronDown className="h-4 w-4" />
              </>
            )}
          </Button>
        </div>
      </div>
      {isExpanded && (
        <div className="border-t bg-gray-50 p-4">
          <h4 className="mb-2 font-medium text-gray-700">Description:</h4>
          <p className="text-gray-600">{description}</p>
        </div>
      )}
    </div>
  )
}

function SeverityBadge({ severity }: { severity: string }) {
  const getVariant = () => {
    switch (severity) {
      case "Low":
        return "bg-blue-50 text-blue-700 border-blue-200"
      case "Medium":
        return "bg-yellow-50 text-yellow-700 border-yellow-200"
      case "High":
        return "bg-red-50 text-red-700 border-red-200"
      default:
        return "bg-gray-50 text-gray-700 border-gray-200"
    }
  }

  return (
    <Badge variant="outline" className={`${getVariant()} font-medium`}>
      {severity}
    </Badge>
  )
}
