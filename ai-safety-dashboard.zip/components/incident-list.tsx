"use client"

import { useState } from "react"
import { IncidentCard } from "./incident-card"
import type { Incident, SeverityType } from "@/lib/types"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { ArrowDownAZ, ArrowUpAZ, Filter } from "lucide-react"

type SortOrder = "newest" | "oldest"

export function IncidentList({ incidents }: { incidents: Incident[] }) {
  const [severityFilter, setSeverityFilter] = useState<SeverityType | "All">("All")
  const [sortOrder, setSortOrder] = useState<SortOrder>("newest")
  const [expandedId, setExpandedId] = useState<number | null>(null)

  // Filter incidents by severity
  const filteredIncidents = incidents.filter((incident) => {
    if (severityFilter === "All") return true
    return incident.severity === severityFilter
  })

  // Sort incidents by date
  const sortedIncidents = [...filteredIncidents].sort((a, b) => {
    const dateA = new Date(a.reported_at).getTime()
    const dateB = new Date(b.reported_at).getTime()
    return sortOrder === "newest" ? dateB - dateA : dateA - dateB
  })

  const toggleSort = () => {
    setSortOrder(sortOrder === "newest" ? "oldest" : "newest")
  }

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id)
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <span className="text-sm font-medium text-gray-700">Filter by:</span>
          <Select value={severityFilter} onValueChange={(value) => setSeverityFilter(value as SeverityType | "All")}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Severities</SelectItem>
              <SelectItem value="Low">Low</SelectItem>
              <SelectItem value="Medium">Medium</SelectItem>
              <SelectItem value="High">High</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button variant="outline" size="sm" onClick={toggleSort} className="flex items-center gap-2">
          {sortOrder === "newest" ? (
            <>
              <ArrowDownAZ className="h-4 w-4" />
              <span>Newest First</span>
            </>
          ) : (
            <>
              <ArrowUpAZ className="h-4 w-4" />
              <span>Oldest First</span>
            </>
          )}
        </Button>
      </div>

      {sortedIncidents.length === 0 ? (
        <div className="rounded-lg border border-dashed p-8 text-center">
          <p className="text-gray-500">No incidents match your filter criteria.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedIncidents.map((incident) => (
            <IncidentCard
              key={incident.id}
              incident={incident}
              isExpanded={expandedId === incident.id}
              onToggleExpand={() => toggleExpand(incident.id)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
