import { IncidentDashboard } from "@/components/incident-dashboard"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="mx-auto max-w-6xl">
        <h1 className="mb-2 text-3xl font-bold text-gray-900">AI Safety Incident Dashboard</h1>
        <p className="mb-8 text-gray-600">Track, monitor, and report AI safety incidents across the organization</p>
        <IncidentDashboard />
      </div>
    </main>
  )
}
